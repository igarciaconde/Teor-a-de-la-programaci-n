package tp.p2;

public enum Direction {

	UP, DOWN, LEFT, RIGHT;
}
