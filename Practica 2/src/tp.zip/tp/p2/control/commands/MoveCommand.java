package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.p2.Direction;
import tp.pr2.control.Controller;

public class MoveCommand extends Command{
	
	private Direction dir;
	public MoveCommand(Direction dir) {
		super("move","Mover ficha en alguna direcion...right, left, up and down." );
		this.dir = dir;
	}

	
	public void execute(Game game, Controller controller) {
		game.move(this.dir);
		game.printG();
	}

	
	public Command parse(String[] commandWords, Controller controller) {
		if(commandWords.length == 1){
			switch(commandWords[0]){
			case("move up"): 
				this.dir= Direction.UP;
				return this;
			case("move down"):
				this.dir= Direction.DOWN;
				return this;
			case("move right"): 
				this.dir= Direction.RIGHT;
				return this;
			case("move left"): 
				this.dir=Direction.LEFT;
				return this;
			default: return null;
			}
			
		}
		else return null;
		
	}

}
