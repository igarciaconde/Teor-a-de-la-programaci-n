package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.pr2.control.Controller;

public class NoParamsCommand extends Command{

	public NoParamsCommand(String commandInfo, String helpInfo) {
		super(commandInfo, helpInfo);
		
	}

	
	public void execute(Game game, Controller controller) {
		
	}

	
	public Command parse(String[] commandWords, Controller controller) {
		
		return null;
	}

}
