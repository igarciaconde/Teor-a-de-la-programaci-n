package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.pr2.control.Controller;

public class ExitCommand extends NoParamsCommand {

	
	public ExitCommand() {
		super("exit", "Salir del programa.");
	}

	
	public void execute(Game game, Controller controller) {
			game.exit();
	}
	
	
	public Command parse(String[] commandWords, Controller controller) {
		if(commandWords.length == 1 && commandWords[0].equalsIgnoreCase("exit")) return this;
		else return null;
	}

}
