package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.pr2.control.Controller;

public class HelpCommand extends NoParamsCommand {
	

	public HelpCommand() {
		super("help", "Muestra el texto de ayuda.");
	}

	
	public void execute(Game game, Controller controller) {
		System.out.println(CommandParse.commandHelp() + System.lineSeparator());
	}

	public Command parse(String[] commandWords, Controller controller) {
		if(commandWords.length == 1 && commandWords[0].equalsIgnoreCase("help")) return this;
		else return null;
	}

}
