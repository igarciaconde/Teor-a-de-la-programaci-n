package tp.p2.control.commands;
import tp.p2.Direction;
import tp.pr2.control.Controller;
public class CommandParse {
	
	private final static Command[] commands=
		{new HelpCommand(), new MoveCommand(Direction.UP), new ResetCommand(),
		 new ExitCommand(), new UndoCommand(), new RedoCommand()};
	
	public static Command parseCommand(String[] commandWords, Controller controller){
		if (commandWords.length > 0 || commandWords.length <= 2){
			Command cm;
			for (Command c:commands) {
			cm=c.parse(commandWords,controller);
			if (cm!=null) return cm;
			
			}
		}
		return null;
		
	}
	
	public static String commandHelp(){
		String ayuda="";
		for (Command c:commands){
			ayuda+= c.helpText() + System.lineSeparator();
		}
		return ayuda;
		
	}

	
}
