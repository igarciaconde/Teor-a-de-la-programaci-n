package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.pr2.control.Controller;

public class UndoCommand extends NoParamsCommand{

	public UndoCommand() {
		super("undo", "Retroceder un movimiento.");
		
	}
	
	public void execute(Game game, Controller controller) {
		game.undo();
		game.printG();
		
	}

	public Command parse(String[] commandWords, Controller controller) {
		if(commandWords.length == 1 && commandWords[0].equalsIgnoreCase("undo")) return this;
		else return null;
	}

}
