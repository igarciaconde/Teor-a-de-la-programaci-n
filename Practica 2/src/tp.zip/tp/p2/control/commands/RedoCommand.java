package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.pr2.control.Controller;

public class RedoCommand extends NoParamsCommand{


	public RedoCommand() {
		super("redo", "Rehacer movimiento deshecho.");
		
	}
	
	public void execute(Game game, Controller controller) {
		game.redo();
		game.printG();
		
	}

	public Command parse(String[] commandWords, Controller controller) {
		if(commandWords.length == 1 && commandWords[0].equalsIgnoreCase("redo")) return this;
		else return null;
	}
}
