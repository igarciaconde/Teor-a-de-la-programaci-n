package tp.p2.control.commands;

import tp.p2.logic.multigames.Game;
import tp.pr2.control.Controller;

public class ResetCommand extends NoParamsCommand {
	
	
	public ResetCommand() {
		
		super("reset","Resetea el juego.");
	}

	
	public void execute(Game game,Controller controller) {
		game.reset();
		game.printG();
	}

	
	public Command parse(String[] commandWords,Controller controller) {
		
		if(commandWords.length == 1 && commandWords[0].equalsIgnoreCase("reset")) return this;
		else return null;
	}

}
