package tp.p2;

public class GameState {

	private int [][] boardState;
	private int score;
	private int boardStateSize;
	
	public GameState(int [][] board, int score, int boardSize) {
		this.boardStateSize = boardSize;
		this.boardState = new int [this.boardStateSize][this.boardStateSize];
		for(int i =0; i < this.boardStateSize;i++) {
			for(int j=0; j < this.boardStateSize; j++) {
				this.boardState[i][j] = board[i][j];
			}
		}
		this.score = score;
		
	}

	public int getScore() {
		return this.score;
	}

	public int [][] getBoardState() {
		return this.boardState;
	}
	



	
	
}
