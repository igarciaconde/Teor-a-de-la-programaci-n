package tp.p2;

public class GameStateList {
	
	private GameState [] estados;
	private static final int CAPACITY = 20;
	private int cuantos;
	
	
	public GameStateList() {
		this.estados = new GameState[CAPACITY];
		this.cuantos = 0;
	}
	
	public GameState pop() {
		// que devuelve el �ltimo estado almacenado,
		if(this.cuantos > 0) {
			if(this.isEmpty()) {
				System.out.println("No hay estados almacenados.");
				return null;
			}
			else {
				int cont = this.cuantos;
				this.cuantos--;
				return this.estados[cont - 1];
			}
		}
		else return null;
	}
	
	public void push(GameState state) {
		// almacena un nuevo estado,
		if(this.cuantos==CAPACITY) {
			for(int i =0; i < CAPACITY - 1; i++) {
				this.estados[i] = this.estados[i + 1];
			}
			this.estados[CAPACITY - 1]= state;
		}
		else if(this.cuantos < CAPACITY) {
			this.estados[cuantos] = state;
			this.cuantos++;
		}
	}
	
	public boolean isEmpty() {
		return this.cuantos==0;
	}
	
	
	public int getCuantos() {
		return this.cuantos;
	}

	
}
