package tp.p2.logic.multigames;
import tp.p2.*;
import java.util.Random;

public interface GameRules {
	
	void addNewCellAt(Board board, Position pos, Random rand);
	
	int merge(Cell self, Cell other);
	
	int getWinValue(Board board);
	
	boolean win(Board board);
	
	default boolean lose(Board board) {
		if(board.fullBoard() && board.noMerge()) return true;
		else return false;
	}
	
	default Board createBoard(int size) {
		Board board = new Board(size);
		return board;
	}
	
	default void addNewCell(Board board, Random rand) {
		
	}
	
	default void initBoard(Board board, int numCells, Random rand) {
		
	}
}
