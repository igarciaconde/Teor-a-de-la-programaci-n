package tp.p2.logic.multigames;
import java.util.Random;


import tp.p2.GameState;
import tp.p2.Board;
import tp.p2.Direction;
import tp.p2.MoveResults;
import tp.p2.Position;
import tp.p2.GameStateList;

public class Game {
	private Board board;// tablero, objeto de la clase Board
	private int size; // size*size tama�o de tablero
	private int initCells;//celdas iniciales
	private long myRandom;//semilla
	private MoveResults gameResults;//objeto gameResult
//	private GameState state;
	private GameStateList ues;//pila de undo
	private GameStateList res;//pila de redo
	private GameRules currentRules;//reglas del juego
	public boolean exit;//condicion de salida directa
	
	
	//La constructora
	public Game(int size, int initCells,long seed) {
		
		this.size = size;
		this.exit = false;
		this.board = new Board(this.size);
		this.gameResults = new MoveResults(0,false);
		this.initCells = initCells;
		this.myRandom = seed;
		//Creamos un array de Position para generar posiciones aleatorias del tablero Board
		Position []aux = new Position[this.size*this.size];
		int k =0;
		for(int i =0; i < this.size; ++i){
			for( int j =0; j < this.size ; ++j){
				aux[k] = new Position(i,j);
				k++;
			}
		}
		//Barajamos el array Position[] para obtener posiciones aleatorias
		shuffle(aux,this.myRandom);
		
		//Damos unos valores iniciales a unas posiciones aleatorias
		for(int l = 0; l < this.initCells;++l){
			this.board.setCell(aux[l], setRandom());
		}
		this.ues = new GameStateList();
		this.res = new GameStateList();
		
	}
	
	//Comprueba que el juego es un game over (no hay movimientos ni fusiones posibles)
	public boolean gameO() {
		if(this.board.fullBoard() && this.board.noMerge()) return true;
		else return false;
	}
	
	//Compreba si alguna Cell == 2048
	public boolean winG() {
		return this.board.win();
	}
	
	//devuelve el valor mas alto del tableo
	public int getWinValue() {
		return this.board.getWinValue();
	}

	//Hace que el board haga un movimiento (llama a executeMove)
	public void move(Direction dir) {
		GameState auxiliar;
		auxiliar = this.getState();
		MoveResults aux = new MoveResults(0,false); 	//objeto auxiliar para recibir los resultados del movimiento
		aux = this.board.executeMove(dir);//Obtenemos el Score y el highest en un auxiliar
		
		
		//Modificamos el moveResults de Game si hay que hacerlo
		this.gameResults.setScore(this.gameResults.getScore() + aux.getScore());
		this.gameResults.setMovement(aux.getMovement());
		
		
		//Si se ha hecho un movimiento, se da un valor a una Cell vac�a
		if(this.gameResults.getMovement() == true){
			this.ues.push(auxiliar);
			for(int i =0;i < this.res.getCuantos();i++) {
				this.res.pop();
			}
			int i = this.board.howManyFree();//numero de vacios en el tablero
			Position[]auxP = new Position[i];
			auxP = this.board.freeCells(i);
			//Barajamos el array de Position
			shuffle(auxP,this.myRandom);
			for(int l = 0; l < 1;++l){//a�adimos un valor nuevo a una celda
				this.board.setCell(auxP[l], setRandom());
			}
		}
	}
	
	//Reinicia el tablero con los datos de entrada del pricipio del progama
	public void reset() {
		this.gameResults = new MoveResults(0,false);
		Position []aux = new Position[this.size*this.size];
		int k =0;
		//Creamos un Position[] auxiliar para crear unas Cell con un valor concreto
		for(int i =0; i < this.size; ++i){
			for( int j =0; j < this.size ; ++j){
				aux[k] = new Position(i,j);
				this.board.setCell(aux[k], 0);
				k++;
			}
		}
		//Barajamos
		shuffle(aux,this.myRandom);
		//Establecemos el valor
		for(int l = 0; l < this.initCells; ++l){
			this.board.setCell(aux[l], setRandom());
		}
		
	}
	
	//Barajamos las posiciones
	public Position[] shuffle (Position[] ar, long r) {
		Random auxRandom = new Random(r);
		int posRandom;
		for (int i = 0; i < ar.length; ++i) {
			posRandom = auxRandom.nextInt((ar.length-1 )-(-1));
			swap(ar, i, posRandom);
		}
		return ar;
	}
	
	//Intercambiamos 2 posiciones
	public void swap (Position[] ar,int i, int j) {
		Position aux = ar[i];
		ar[i] = ar[j];
		ar[j] = aux;
	}
	
	//Devolvemos un entero igual a 2 o igual a 4  
	public int setRandom(){
		int randomValue;
		 Random r = new Random();
		 randomValue = r.nextInt(100 - 1) + 1;
		 if(randomValue < 90) return 2;
		 else return 4;
	}
	
	//Sacar en pantalla el Game
	public void printG(){
		
		this.board.print();
		System.out.print("\n");
		System.out.print("mejor: " + Integer.toString(this.getWinValue()) + "       score: " + Integer.toString(this.gameResults.getScore()) + "\n");
	}
	
	//nos indica si queremos salir del juego o no
	public void exit() {
		this.exit = true;
	}
	
	
	
	//Devuelve el estado de juego actual para guardarlo
	public GameState getState() {
		GameState aux = new GameState(this.board.getState(),this.gameResults.getScore(),this.size);
		return aux;
	}
	//Recoge el ultimo estado de juego guardado y lo carga
	public void setState(GameState aState) {
		this.board.setState(aState.getBoardState());
		this.gameResults.setScore(aState.getScore());
	}
	
	//Deshacer movimiento
	public void undo() {
		
 		if(!this.ues.isEmpty()){
			this.res.push(this.getState());
			this.setState(this.ues.pop());
			System.out.println("Undoing movement...");
		}
		else System.out.println("No se pueden deshacer movimientos.");
	}
	//Rehacer movimiento
	public void redo() {
		if(!this.res.isEmpty()){
			this.ues.push(this.getState());
			this.setState(this.res.pop());
			System.out.println("Redoing movement...");
		}
		else System.out.println("No se pueden rehacer movimientos.");
	}
	
	
	
}
