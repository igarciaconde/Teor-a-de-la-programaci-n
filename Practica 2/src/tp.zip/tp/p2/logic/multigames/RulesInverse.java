package tp.p2.logic.multigames;

import tp.p2.*;
import java.util.Random;

public class RulesInverse implements GameRules {

	
	public void addNewCellAt(Board board, Position pos, Random rand) {
		int randomValue;
		 randomValue = rand.nextInt(100 - 1) + 1;
		 if(randomValue < 90) board.setCell(pos, 2048);
		 else board.setCell(pos, 1024);
		
	}
	
	public boolean canMerge(Cell self, Cell other) {
		return self.getValue()==other.getValue();
	}
	
	public int merge(Cell self, Cell other) {
		
		if(canMerge(self, other)) {
			int div = self.getValue() / 2;
			return div;
		}
		else return 0;
	}

	
	public int getWinValue(Board board) {
		
		int min=2048;
		Position aux;
		for(int i =0 ;i < board.getBoardSize();i++) {
			for(int j =0; j < board.getBoardSize() ;j++) {
				aux = new Position(i,j);
				if(board.getValue(aux) < min) {
					min = board.getValue(aux);
				}
			}
		}
		return min;
	}

	
	public boolean win(Board board) {
		
		if (getWinValue(board)== 1)return true;
		else return false;
	}

}
