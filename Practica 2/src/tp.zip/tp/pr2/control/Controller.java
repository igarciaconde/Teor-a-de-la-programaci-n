package tp.pr2.control;

import tp.p2.control.commands.Command;
import tp.p2.control.commands.CommandParse;
import java.util.Scanner;
import tp.p2.logic.multigames.Game;

public class Controller {

	private Game game;
	private Scanner in;
	
	
	public Controller(int size,int initCells,long seed){//constructora
		this.game = new Game(size,initCells,seed);
		this.in = new Scanner(System.in);
	}
	
	//El m�todo principal, hace que el usuario juegue
	public void run() {
		
		this.game.printG();
		while(!game.gameO() && !game.exit){
			System.out.print("Command > ");
			String[] words = in.nextLine().toLowerCase().trim().split(" s+");
			Command c = CommandParse.parseCommand(words,this);
			if(c!= null) {
				c.execute(game, this);
			}
			else System.out.println("Comando erroneo.");
		}
		
	}
}
